package estoque;

public class Disponivel extends StateEstoque {

    public Disponivel(Produto produto) {
        super(produto);
    }

    @Override
    public void setLimite() {
        this.setMinimo(5);
        this.atualizaStatus();
    }

    @Override
    public void atualizaStatus() {
        if (this.getProduto().getQuantidadeEstoque() <= this.getMinimo())
            this.getProduto().setStatus(new Acabando(this.getProduto()));
    }
    
}
