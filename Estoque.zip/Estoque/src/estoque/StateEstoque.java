package estoque;

public abstract class StateEstoque {
    
    private Produto produto;
    private int minimo;
    
    public StateEstoque(Produto produto) {
        this.produto = produto;
        this.setLimite();
    }
    
    public void atualizaEstoque() {
        this.produto.setQuantidadeEstoque(this.produto.getQuantidadeEstoque() - 1);
        this.atualizaStatus();
    }
    
    public abstract void setLimite();
    
    public abstract void atualizaStatus();

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public int getMinimo() {
        return minimo;
    }

    public void setMinimo(int minimo) {
        this.minimo = minimo;
    }

}
