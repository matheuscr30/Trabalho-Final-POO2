package estoque;

public class Esgotado extends StateEstoque {

    public Esgotado(Produto produto) {
        super(produto);
    }

    @Override
    public void setLimite() {
        this.setMinimo(0);
        this.atualizaStatus();}

    @Override
    public void atualizaStatus() {
        if (this.getProduto().getQuantidadeEstoque() > this.getMinimo()) {
            this.getProduto().setStatus(new Esgotado(this.getProduto()));
        }
    }

}
