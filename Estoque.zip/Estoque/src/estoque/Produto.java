package estoque;

import java.io.Serializable;

/**
 * Created by matheus on 15/12/17.
 */

public class Produto implements Serializable{

    private String referencia;
    private String nome;
    private String descricao;
    private String cor;
    private String tipo;
    private String genero;
    private String tamanho;
    private String preco;
    private Integer quantidadeEstoque;
    private StateEstoque status;

    public Produto() {
        this.status = new Disponivel(this);
        this.quantidadeEstoque = 10;
    }
    
    public void atualizaEstoque() {
        status.atualizaEstoque();
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getTamanho() {
        return tamanho;
    }

    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }

    public String getPreco() {
        return preco;
    }

    public void setPreco(String preco) {
        this.preco = preco;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public Integer getQuantidadeEstoque() {
        return quantidadeEstoque;
    }

    public void setQuantidadeEstoque(Integer quantidadeEstoque) {
        this.quantidadeEstoque = quantidadeEstoque;
    }

    public StateEstoque getStatus() {
        return status;
    }

    public void setStatus(StateEstoque status) {
        this.status = status;
    }
    
}