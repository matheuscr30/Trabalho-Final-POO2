package estoque;

public class Acabando extends StateEstoque {

    public Acabando(Produto produto) {
        super(produto);
    }

    @Override
    public void setLimite() {
        this.setMinimo(0);
        this.atualizaStatus();
    }

    @Override
    public void atualizaStatus() {
        if (this.getProduto().getQuantidadeEstoque() == this.getMinimo()) {
            this.getProduto().setStatus(new Esgotado(this.getProduto()));
        } else if (this.getProduto().getQuantidadeEstoque() > 5){
            this.getProduto().setStatus(new Disponivel(this.getProduto()));
        }
    }

}
